<h2><?= $title ?></h2>
<p>Social Blog </p>
