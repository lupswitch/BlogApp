<h2><?= $title ?></h2>
<p>Welcome to Blog App</p>
